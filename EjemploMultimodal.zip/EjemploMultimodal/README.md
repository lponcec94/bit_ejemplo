# 🤝 Asesor de Impacto Social Multimodal con Gemini AI

Una aplicación web avanzada que conecta con la API de Gemini para proporcionar asesoramiento personalizado sobre proyectos de impacto social con **soporte para imágenes**.

## 🚀 Características Multimodales

- **🖼️ Análisis de imágenes**: Sube fotos de tu proyecto, comunidad o contexto
- **💬 Procesamiento de texto**: Describe tu proyecto social en detalle
- **🤖 IA multimodal**: Gemini analiza tanto texto como imágenes juntos
- **📱 Interface responsive**: Diseño moderno que funciona en todos los dispositivos
- **🔄 Drag & Drop**: Arrastra y suelta imágenes fácilmente
- **📊 Respuestas estructuradas**: JSON con consejos, pasos y recursos

## 📋 Requisitos

- Node.js (v14 o superior)
- API Key de Gemini (configurada en `.env`)
- Navegador web moderno

## 🛠️ Instalación

1. **Instalar dependencias**:
   ```bash
   cd EjemploMultimodal
   npm install
   ```

2. **Configurar variables de entorno**:
   Asegúrate de que tu archivo `.env` contenga:
   ```
   GEMINI_API_KEY=tu_api_key_aqui
   ```

## 🏃‍♂️ Ejecutar la aplicación

1. **Iniciar el servidor**:
   ```bash
   npm start
   # o
   node server.js
   ```

2. **Acceder a la aplicación**:
   Abre tu navegador en: http://localhost:3000

## 📁 Estructura del proyecto

```
EjemploMultimodal/
├── public/
│   └── index.html          # Frontend multimodal
├── .env                    # Variables de entorno
├── package.json           # Dependencias (incluye multer)
├── server.js              # Servidor con soporte para imágenes
└── README.md              # Este archivo
```

## 🔗 Endpoints

### POST /api/consultar (Multimodal)
Recibe consultas con texto y opcionalmente imágenes.

**Form Data:**
- `prompt`: Pregunta o consulta (texto)
- `contextoSocial`: Contexto del proyecto (texto)
- `imagen`: Archivo de imagen (opcional)

**Response:**
```json
{
  "respuesta": "Consejo personalizado...",
  "pasos_a_seguir": ["Paso 1", "Paso 2"],
  "recursos_sugeridos": ["Recurso 1", "Recurso 2"],
  "analisis_imagen": "Análisis de la imagen si se proporcionó"
}
```

### POST /api/consultar-texto (Solo texto)
Endpoint optimizado para consultas sin imágenes (usa gemini-2.5-flash).

**Response:**
```json
{
  "respuesta": "Consejo personalizado...",
  "pasos_a_seguir": ["Paso 1", "Paso 2"],
  "recursos_sugeridos": ["Recurso 1", "Recurso 2"]
}
```

### GET /api/health
Endpoint para verificar el estado del servidor.

**Response:**
```json
{
  "status": "Server is running",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "endpoints": ["/api/consultar", "/api/consultar-texto"],
  "features": ["text", "image-upload", "multimodal"]
}
```

### GET /api/image-info
Información sobre formatos de imagen soportados.

**Response:**
```json
{
  "supportedFormats": ["JPEG", "PNG", "GIF", "BMP", "WEBP"],
  "maxSize": "10MB",
  "maxDimensions": "No specific limit (recommended: < 2048x2048)"
}
```

## 🎯 Uso Avanzado

### 1. **Subida de Imágenes**
- **Formatos soportados**: JPEG, PNG, GIF, BMP, WEBP
- **Tamaño máximo**: 10MB
- **Métodos**: Click para seleccionar o arrastrar y soltar

### 2. **Casos de Uso con Imágenes**
- 📸 **Fotos del proyecto**: Muestra tu espacio de trabajo
- 👥 **Comunidad**: Comparte imágenes de las personas que atiendes
- 🏗️ **Infraestructura**: Sube fotos de tus instalaciones
- 📊 **Documentos**: Capturas de pantallas de métricas o reportes

### 3. **Ejemplos de Consultas**

**Con imagen de un espacio comunitario:**
```
Contexto: Espacio comunitario en zona rural
Pregunta: ¿Cómo puedo optimizar este espacio para talleres educativos?
```

**Con imagen de un evento:**
```
Contexto: Organización de eventos benéficos
Pregunta: ¿Qué mejoras sugieres para el próximo evento basándote en esta foto?
```

## 🛡️ Seguridad y Validación

- **Validación de archivos**: Solo se permiten imágenes
- **Límite de tamaño**: Máximo 10MB por archivo
- **Manejo de errores**: Robusto con mensajes claros
- **API Key protegida**: Variables de entorno

## 🐛 Troubleshooting

### Problemas comunes:

1. **Error al subir imagen**:
   - Verifica el formato (debe ser imagen)
   - Confirma el tamaño (< 10MB)
   - Revisa conexión a internet

2. **Error de API Key**:
   - Verifica que tu API Key sea válida
   - Confirma que esté en el archivo `.env`

3. **Error de procesamiento**:
   - Algunas imágenes muy grandes pueden tardar
   - Intenta con imágenes más pequeñas si hay problemas

### Logs de error:
Los errores se muestran en la consola del servidor para facilitar el debugging.

## 📝 Notas Técnicas

- **Modelo multimodal**: `gemini-1.5-flash` para texto + imágenes
- **Modelo texto**: `gemini-2.5-flash` para solo texto (más económico)
- **Upload**: Usando `multer` para manejo de archivos
- **Base64**: Las imágenes se convierten a base64 para la API
- **Frontend**: Vanilla JavaScript con drag & drop

## 🌟 Mejoras vs Versión Simple

| Característica | Simple | Multimodal |
|---|---|---|
| 📝 Procesamiento de texto | ✅ | ✅ |
| 🖼️ Análisis de imágenes | ❌ | ✅ |
| 🔄 Drag & Drop | ❌ | ✅ |
| 📱 Vista previa de imágenes | ❌ | ✅ |
| 🤖 Modelos especializados | 1 | 2 |
| 📊 Análisis contextual | Básico | Avanzado |

## 🚀 Siguientes Pasos

1. **Prueba con diferentes tipos de imágenes**
2. **Experimenta con consultas específicas**
3. **Combina múltiples contextos**
4. **Mide el impacto de las recomendaciones**
